# Setup and control requirements

1. Review each task and source reference with the accountable human.
2. Establish legitimate authority separately from technical access.
3. Configure and test a bounded runtime adapter.
4. Obtain exact-version approvals in the customer approval system.
5. Prove enforcement and revocation before execution.

No runtime adapter is provisioned by this package. Missing and excluded records are listed in manifest.json. Raw recordings and source text are omitted.
