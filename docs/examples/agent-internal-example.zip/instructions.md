# Northstar Parts — Advisor Training 2026-09-05 21:13

Purpose: Practice evidence review, human confirmation, bounded work, measurement and client reporting.

DRAFT INSTRUCTIONS. This package grants no authority and does not deploy an agent.

## Check the incoming order (v2)

Inspect the named inputs. Record the result and source reference. Stop and ask Jamie when information is incomplete or inconsistent.

Human checkpoint: Jamie reviews exceptions before any human release.

Do not: Change customer credit limits; Release orders automatically; Use production credentials
