# Northstar Parts — weekly training example

Open client-report.html in a browser; use Print / Save as PDF for a paper copy.

Audience: Alex Morgan, fictional sponsor; Jamie Park, fictional fulfillment lead

This is a frozen, reviewed manual-delivery packet. No email was sent. The source remains the company workspace. Raw evidence and credentials are excluded.
